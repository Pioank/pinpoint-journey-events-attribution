import os
import json
import boto3
from datetime import date
from boto3.dynamodb.conditions import Key, Attr

region = os.environ['AWS_REGION']
userpoolid = os.environ['COGNITO_USER_POOL_ID']
client = boto3.client('cognito-idp')
dynamodbendpointurl = "https://dynamodb." + region + ".amazonaws.com"
dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodbendpointurl)
table = dynamodb.Table('pinpoint_journey_attribution')

today = date.today()
today = today.strftime("%Y/%m/%d")

def lambda_handler(event, context):
    records = table.scan(FilterExpression=Attr('exp_date').lt(today))
    if 'LastEvaluatedKey' in records:
        recordprocessing(records)
        while 'LastEvaluatedKey' in records:
            records = table.scan(FilterExpression=Attr('exp_date').lt(today), ExclusiveStartKey=records['LastEvaluatedKey'])
    else:
        recordprocessing(records)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

# Removes value from Cognito User Custom Attribute Campaign
def updatecognito(username):
    response = client.admin_update_user_attributes(
        UserPoolId=userpoolid,
        Username=username,
        UserAttributes=[
            {
                'Name': 'custom:campaign',
                'Value': ''
            },
        ]
    )
    print('Cognito User Attribute updated successfully')

# Checking all DynamoDB records
def recordprocessing(records):
    records = records['Items']
    for record in records:
        print(record)
        expdate = record['exp_date']
        userjour = str(record['user_journey'])
        username = userjour.split('_')[0]
        
        print('Record deleted from DynamoDB')
        
        table.delete_item(Key={'user_journey': userjour})
        updatecognito(username)
    
    if len(records) == 0:
        print('No records that require expiration found')