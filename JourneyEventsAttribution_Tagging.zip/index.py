import os
import json
import boto3
from interaction_function import pushdata, get_journeyname, updatecognito, checkrecordexists, updateexpdate

def lambda_handler(event, context):
    endpointid = event['Endpoints']
    endpointid=list(endpointid.keys())[0]
    journeyid = str(event['JourneyId'])
    
    try:
        username = event['Endpoints'][endpointid]['User']['UserAttributes']['username']
        username = str(username[0])
        journeyname = get_journeyname(journeyid)
        userjour = str(username) + "_" + str(journeyname)
    except:
        print('No username found')
    else:
        print("The Journey name is: ", journeyname)
        print("The username is: ", username)
        
        queryresults = checkrecordexists(userjour)

        if len(queryresults['Items']) != 0:
            print('Record Exist - Expiration date will be updated')
            oldexpdate = queryresults['Items'][0]['exp_date']
            updateexpdate(userjour,oldexpdate,journeyname)
        else:
            print('Record doesnt exist')
            pushdata(userjour,journeyname, username)
            updatecognito(username,journeyname)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Process completed')
    }

