import os
import boto3
from datetime import date
import datetime
import calendar
import time
from boto3.dynamodb.conditions import Key

region = os.environ['AWS_REGION']
lookbackwindow = int(os.environ['LOOKBACK_WINDOW_DAYS'])
userpoolid = os.environ['COGNITO_USER_POOL_ID']
pinappid = os.environ['PINPOINT_APP_ID']

dynamodbendpointurl = "https://dynamodb." + region + ".amazonaws.com"

dynamodb = boto3.resource('dynamodb', endpoint_url=dynamodbendpointurl)
table = dynamodb.Table('pinpoint_journey_attribution')
client = boto3.client('cognito-idp')
clientp = boto3.client('pinpoint')

today = date.today()

# Creates a DynamoDB record
def pushdata(userjour,journeyname, username):
    exp_date = expdategen()
    exp_date_TTL = expdateTTL()
    
    table.put_item(
       Item={
            'user_journey': userjour,
            'exp_date': exp_date,
            'exp_date_TTL': exp_date_TTL,
            'username': username
            }
    )
    print('User - Journey combination has been recorded: ' + userjour)
    
 
# Checks if the record of User-Campaign and Exp_date already exists in DynamoDB   
def checkrecordexists(userjour):
    queryresults = table.query(KeyConditionExpression=Key('user_journey').eq(userjour))
    return queryresults

#Updates the Cognito User Custom:Campaign value
def updatecognito(username, journeyname):
    response = client.admin_update_user_attributes(
        UserPoolId=userpoolid,
        Username=username,
        UserAttributes=[
            {
                'Name': 'custom:campaign',
                'Value': journeyname
            },
        ]
    )
    print('Cognito User Attribute updated successfully')

# Gets the Jouyrney name by providing the journey ID obtained from the event Payload that triggers the Lambda
def get_journeyname(journeyid):
    response = clientp.get_journey(
    ApplicationId=pinappid,
    JourneyId=journeyid
    )
    response = str(response['JourneyResponse']['Name'])
    return response

# If record exists in DynamoDB then delete it and insert new one with updated date   
def updateexpdate(userjour, oldexp_date, journeyname):
    exp_date = expdategen()
    exp_date_TTL = expdateTTL()   
    response = table.update_item(
        Key={
            'user_journey': userjour
        },
        UpdateExpression="set exp_date=:r, exp_date_TTL=:p",
        ExpressionAttributeValues={
            ':r': exp_date,
            ':p': exp_date_TTL
        },
        ReturnValues="UPDATED_NEW"
        )
    print('User s expiration date has been updated')
    

#Generates an expiration date today + No of days defined in the code 
def expdategen():
    exp_date = today + datetime.timedelta(days=lookbackwindow)
    exp_date = exp_date.strftime("%Y/%m/%d")
    
    return exp_date

#Generates an expiration date in UNIX EPOCH for the DynamoDB TTL
def expdateTTL():
    exp_date_TTL = today + datetime.timedelta(days=lookbackwindow)
    time_stamp = datetime.datetime.now().strftime("%H:%M:%S")
    exp_date_TTL = str(exp_date_TTL) + " " + time_stamp
    exp_date_TTL = calendar.timegm(time.strptime(exp_date_TTL, '%Y-%m-%d %H:%M:%S'))
    
    return exp_date_TTL